
package dlp6.danlp6.moreitemsmod6.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.ShearsItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.block.BlockState;

import dlp6.danlp6.moreitemsmod6.itemgroup.MoreItems6ItemGroup;
import dlp6.danlp6.moreitemsmod6.Moreitemsmod6ModElements;

@Moreitemsmod6ModElements.ModElement.Tag
public class RubySheersItem extends Moreitemsmod6ModElements.ModElement {
	@ObjectHolder("moreitemsmod6:ruby_sheers")
	public static final Item block = null;
	public RubySheersItem(Moreitemsmod6ModElements instance) {
		super(instance, 28);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ShearsItem(new Item.Properties().group(MoreItems6ItemGroup.tab).maxDamage(6000)) {
			@Override
			public int getItemEnchantability() {
				return 600;
			}

			@Override
			public float getDestroySpeed(ItemStack stack, BlockState block) {
				return 60f;
			}
		}.setRegistryName("ruby_sheers"));
	}
}
