
package dlp6.danlp6.moreitemsmod6.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.SwordItem;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;

import dlp6.danlp6.moreitemsmod6.itemgroup.RubyMoreitemsmod6ItemGroup;
import dlp6.danlp6.moreitemsmod6.Moreitemsmod6ModElements;

@Moreitemsmod6ModElements.ModElement.Tag
public class RubySwordItem extends Moreitemsmod6ModElements.ModElement {
	@ObjectHolder("moreitemsmod6:ruby_sword")
	public static final Item block = null;
	public RubySwordItem(Moreitemsmod6ModElements instance) {
		super(instance, 21);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new SwordItem(new IItemTier() {
			public int getMaxUses() {
				return 6000;
			}

			public float getEfficiency() {
				return 16f;
			}

			public float getAttackDamage() {
				return 14f;
			}

			public int getHarvestLevel() {
				return 6;
			}

			public int getEnchantability() {
				return 46;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.EMPTY;
			}
		}, 3, -3.4f, new Item.Properties().group(RubyMoreitemsmod6ItemGroup.tab)) {
		}.setRegistryName("ruby_sword"));
	}
}
