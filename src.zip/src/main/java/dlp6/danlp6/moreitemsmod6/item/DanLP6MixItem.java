
package dlp6.danlp6.moreitemsmod.item;

import net.minecraftforge.registries.ObjectHolder;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.util.ResourceLocation;
import net.minecraft.item.Rarity;
import net.minecraft.item.MusicDiscItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;

import dlp6.danlp6.moreitemsmod.itemgroup.MoreItemsItemGroup;
import dlp6.danlp6.moreitemsmod.Moreitemsmod6ModElements;

@Moreitemsmod6ModElements.ModElement.Tag
public class DanLP6MixItem extends Moreitemsmod6ModElements.ModElement {
	@ObjectHolder("moreitemsmod6:dan_lp_6_mix")
	public static final Item block = null;
	public DanLP6MixItem(Moreitemsmod6ModElements instance) {
		super(instance, 4);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new MusicDiscItemCustom());
	}
	public static class MusicDiscItemCustom extends MusicDiscItem {
		public MusicDiscItemCustom() {
			super(0, (net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.anvil.place")),
					new Item.Properties().group(MoreItemsItemGroup.tab).maxStackSize(1).rarity(Rarity.RARE));
			setRegistryName("dan_lp_6_mix");
		}

		@Override
		@OnlyIn(Dist.CLIENT)
		public boolean hasEffect(ItemStack itemstack) {
			return true;
		}
	}
}
