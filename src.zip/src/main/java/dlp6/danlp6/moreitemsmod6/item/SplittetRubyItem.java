
package dlp6.danlp6.moreitemsmod6.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.UseAction;
import net.minecraft.item.Rarity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.Food;

import dlp6.danlp6.moreitemsmod6.itemgroup.RubyMoreitemsmod6ItemGroup;
import dlp6.danlp6.moreitemsmod6.Moreitemsmod6ModElements;

@Moreitemsmod6ModElements.ModElement.Tag
public class SplittetRubyItem extends Moreitemsmod6ModElements.ModElement {
	@ObjectHolder("moreitemsmod6:splittet_ruby")
	public static final Item block = null;
	public SplittetRubyItem(Moreitemsmod6ModElements instance) {
		super(instance, 17);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new FoodItemCustom());
	}
	public static class FoodItemCustom extends Item {
		public FoodItemCustom() {
			super(new Item.Properties().group(RubyMoreitemsmod6ItemGroup.tab).maxStackSize(46).rarity(Rarity.RARE)
					.food((new Food.Builder()).hunger(16).saturation(0.1f).build()));
			setRegistryName("splittet_ruby");
		}

		@Override
		public UseAction getUseAction(ItemStack itemstack) {
			return UseAction.EAT;
		}
	}
}
