
package dlp6.danlp6.moreitemsmod6.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;

import dlp6.danlp6.moreitemsmod6.itemgroup.RubyMoreitemsmod6ItemGroup;
import dlp6.danlp6.moreitemsmod6.Moreitemsmod6ModElements;

@Moreitemsmod6ModElements.ModElement.Tag
public class RubyShovelItem extends Moreitemsmod6ModElements.ModElement {
	@ObjectHolder("moreitemsmod6:ruby_shovel")
	public static final Item block = null;
	public RubyShovelItem(Moreitemsmod6ModElements instance) {
		super(instance, 24);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ShovelItem(new IItemTier() {
			public int getMaxUses() {
				return 6000;
			}

			public float getEfficiency() {
				return 60f;
			}

			public float getAttackDamage() {
				return 34f;
			}

			public int getHarvestLevel() {
				return 6;
			}

			public int getEnchantability() {
				return 60;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.EMPTY;
			}
		}, 1, -3.4f, new Item.Properties().group(RubyMoreitemsmod6ItemGroup.tab)) {
		}.setRegistryName("ruby_shovel"));
	}
}
