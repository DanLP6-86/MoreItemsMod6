
package dlp6.danlp6.moreitemsmod6.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import dlp6.danlp6.moreitemsmod6.item.DanLP6MixItem;
import dlp6.danlp6.moreitemsmod6.Moreitemsmod6ModElements;

@Moreitemsmod6ModElements.ModElement.Tag
public class MoreItems6ItemGroup extends Moreitemsmod6ModElements.ModElement {
	public MoreItems6ItemGroup(Moreitemsmod6ModElements instance) {
		super(instance, 9);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabmore_items_6") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(DanLP6MixItem.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static ItemGroup tab;
}
