
package dlp6.danlp6.moreitemsmod.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import dlp6.danlp6.moreitemsmod.item.DanLP6MixItem;
import dlp6.danlp6.moreitemsmod.Moreitemsmod6ModElements;

@Moreitemsmod6ModElements.ModElement.Tag
public class MoreItemsItemGroup extends Moreitemsmod6ModElements.ModElement {
	public MoreItemsItemGroup(Moreitemsmod6ModElements instance) {
		super(instance, 4);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabmore_items") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(DanLP6MixItem.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static ItemGroup tab;
}
