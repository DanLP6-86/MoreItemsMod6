
package dlp6.danlp6.moreitemsmod.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import dlp6.danlp6.moreitemsmod.item.RubyItem;
import dlp6.danlp6.moreitemsmod.Moreitemsmod6ModElements;

@Moreitemsmod6ModElements.ModElement.Tag
public class MoreItemsMond6ItemGroup extends Moreitemsmod6ModElements.ModElement {
	public MoreItemsMond6ItemGroup(Moreitemsmod6ModElements instance) {
		super(instance, 1);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabmore_items_mond_6") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(RubyItem.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static ItemGroup tab;
}
