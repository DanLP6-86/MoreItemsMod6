
package dlp6.danlp6.moreitemsmod6.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import dlp6.danlp6.moreitemsmod6.item.RubyItem;
import dlp6.danlp6.moreitemsmod6.Moreitemsmod6ModElements;

@Moreitemsmod6ModElements.ModElement.Tag
public class RubyMoreitemsmod6ItemGroup extends Moreitemsmod6ModElements.ModElement {
	public RubyMoreitemsmod6ItemGroup(Moreitemsmod6ModElements instance) {
		super(instance, 1);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabruby_moreitemsmod_6") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(RubyItem.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static ItemGroup tab;
}
